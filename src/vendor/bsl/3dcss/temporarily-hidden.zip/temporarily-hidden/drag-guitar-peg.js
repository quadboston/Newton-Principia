( function() {
    var {
        ns, sn, $$, haz, haff,
        nsmethods,
        mat,
    } = window.b$l.nstree();
    window.onload = test;
    return;








    function test()
    {
        createsPegsPopulation({
            sceneName       : 'pegs', //must be CSS friendly
            scenepos        : [ 100,100 ],
            pegsPos         : [
                //in screen coordinates
                [ 100, -100, 0 ],
                [ 200, -200, 0 ],
                [ 300, -200, 0 ],
            ],
            scale : 0.5,
        });
    }


    function createsPegsPopulation({
            scenepos,
            pegsPos,
            sceneName,
            scale,
    }){

        var LAYERS_COUNT        = 5;
        var THICKNESS           = 30;
        var backgroundColor     = 'rgba( 100,100,100 , 1 )';
        var spriteInitialPos    = [ 0,0 ];
        var scene               = {
            pegs : []
        };
        var styleTagName        = 'scene-' + sceneName;

        addsCommonCss();

        /*
        var superscene$ = $$.div()
            .addClass( styleTagName )
            .css( 'left', '0px' )
            .css( 'top',  '0px' )
            .css( 'transform', 'scale('+scale.toFixed(4)+')' )
            .to( document.body )
            ;
        scene.dom$ = $$.div()
            .addClass( styleTagName )
            .css( 'left', scenepos[0]+'px' )
            .css( 'top',  scenepos[1]+'px' )
            //.css( 'transform', 'scale('+scale.toFixed(4)+')' )
            //.to( document.body )
            .to( superscene$ )
            ;
        */
        scene.dom$ = $$.div()
            .addClass( styleTagName )
            .css( 'left', scenepos[0]+'px' )
            .css( 'top',  scenepos[1]+'px' )
            .to( document.body )
            ;


        pegsPos.forEach( (pegPos, pix) => {
            var peg = scene.pegs[ pix ] = { initialPos:pegPos, sprites : [] };
            createsSprites( peg, pix );
            nsmethods.rgX_2_dragWrap({
                acceptPos,
                pos         : [ peg.initialPos[0], -peg.initialPos[1], ],
                dragSurface : scene.dom$(),
            });
            //makes initial display by 0-move-d8d
            completeScene( null, [0,0] );
            return;

            function acceptPos( newPos, dragMove )
            {
                completeScene( newPos, dragMove );
                return false;
            }

            function completeScene( newPos, dragMove )
            {
                peg.sprites.forEach( (sprite,six) => {
                    mat.rotateDiv({
                        sprite,
                        scene,
                        rotationSequence :
                        [
                            { axisIx : 0, angle : -Math.PI * ( dragMove[1] / 1000 ), },
                            //{ axisIx : 0, angle : -Math.PI * ( dragMove[1] / 600 ), },
                        ],
                    });
                });
            }

        });
        return;





        function createsSprites( peg, pix )
        {
            for( six=0; six<LAYERS_COUNT; six++ ) {
                var sprite = {  pegIx : pix, spriteIx : six, };
                sprite.currentPosition =
                [
                    [ 1,    0,      0,      spriteInitialPos[0] ],
                    [ 0,    1,      0,      spriteInitialPos[1] ],
                    [ 0,    0,      1,      -six*THICKNESS/LAYERS_COUNT ],
                    [ 0,    0,      0,      1 ],
                ];

                sprite.finalTransf =
                    [
                        [-0.7107995,  0, 0.70339469,  0],
                        [0,           1, 0,           0],
                        [-0.70339469, 0, -0.7107995,  0],
                        [0, 0, 0, 1]
                    ];

                var spriteId = 'peg-' + pix + '-' + six;
                sprite.dom$ = $$
                    .div()
                    .addClass( 'sprite'+spriteId + ' sprite' )
                    .to( scene.dom$ ) 
                    ;
                sprite.dom = sprite.dom$();
                peg.sprites[ six ] = sprite;
            }
            ns.globalCss.update( '', styleTagName );
        }








        function addsCommonCss()
        {
            //good to consider: backface-visibility: hidden
            ns.globalCss.addText(
                `
                    .${styleTagName} {
                        position             : absolute;
                        width                : 600px;
                        height               : 600px;
                        border               : 1px solid blue;
                        perspective          : 1000px;
                        perspective-origin   : 50px 50px;
                        transform-style      : preserve-3d
                        overflow             : visible;
                    }
                    .sprite {
                        position            : absolute;
                        width               : 100px;
                        height              : 100px;
                        border-radius       : 50px;
                        border              : 5px inset grey;
                        text-align          : center;
                        background-color    : rgba( 100,100,100, 1 );
                    }
                `,
               styleTagName
            );
        }
    }


}) ();


