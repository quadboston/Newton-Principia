( function() {
    var {
        ns, sn, haz, haff, nsmethods, d8d_p,
    } = window.b$l.nstree();
    nsmethods.rgX_2_dragWrap  = rgX_2_dragWrap;
    return;








    function rgX_2_dragWrap({
        acceptPos,
        pos,
        dragSurface,

        //optionals:
        DRAGGEE_HALF_SIZE,
        mediaOffset,
        innerMediaWidth,
        mediaWidth,
    }){
        //-----------------------------------
        // //\\ fills optionals
        //-----------------------------------
        DRAGGEE_HALF_SIZE       = DRAGGEE_HALF_SIZE || 40;
        mediaOffset             = mediaOffset       || [0,0];
        innerMediaWidth         = innerMediaWidth   || 1000;
        mediaWidth              = mediaWidth        || 1000;
        //-----------------------------------
        // \\// fills optionals
        //-----------------------------------


        //-----------------------------------
        // //\\ prepares point
        //-----------------------------------
        var pointWrap = //was rgX =
        {
            pname                   : 'mytest',
            color                   : 'rgba( 0,0,255, 0.8 )',
            pos,
            medpos                  : pos,
            DRAGGEE_HALF_SIZE       : 40,
            acceptPos               : acceptPos || ( _=>true ),
            move_2_updates          : move_2_updates,
            processDownEvent        : processDownEvent,
            processUpEvent          : processUpEvent,
        };
        pointWrap.spinnerClsId      = 'point-' + pointWrap.pname + '-slider';
        pointWrap.dragDecorColor    = haz( pointWrap, 'dragDecorColor' ) || pointWrap.pcolor;
        //-----------------------------------
        // \\// prepares point
        //-----------------------------------



        //-----------------------------------
        // //\\ prepares framework
        //-----------------------------------
        var medD8D = d8d_p.createFramework({
            findDraggee                         : findDraggee,
            dragSurface,
            inn2outparent                       : inn2outparent,
        });
        //-----------------------------------
        // \\// prepares framework
        //-----------------------------------



        //-----------------------------------
        // //\\ prepares dragWrap
        //-----------------------------------
        var argc =
        {
            pointWrap,
            doProcess,
            //orientation         : orientation,
            //nospinner           : true, //this cancels? inn2outparent 
        };
        medD8D.pointWrap_2_dragWrap( argc );
        //-----------------------------------
        // \\// prepares dragWrap
        //-----------------------------------
        return;








        //====================
        // //\\ finds draggee
        //====================
        ///Uses:    sDomF.outparent2inn( testPoint );
        ///
        ///Returns: point drag Wrap
        ///         which is closest to testPoint.
        function findDraggee( point_on_dragSurf, dragWraps ) //, dragSurface )
        {
            var pOnS = point_on_dragSurf;
            //.if distance to pOnS is "outside" of this par.,
            //.then dragWrap is not "considered" for drag
            var DRAGGEE_HALF_SIZE = 40;

            var closestDragWrap = null;
            var closestTd = null;
            //.the bigger is priority, the more "choicable" is the drag Wrap point
            var closestDragPriority = 0;

            var testMedpos = outparent2inn( pOnS );
            var testMediaX = testMedpos[0];
            var testMediaY = testMedpos[1];

            var unfoundDragger = null;
            dragWraps.forEach( function( dragWrap, dix ) {
                var dragPoint   = dragWrap.pointWrap;

                if( ns.haz( dragPoint, 'unfound' ) ) {
                    unfoundDragger = dragWrap;
                    return;
                }
                //if( dragPoint.pname === 'loose1' ) {
                //    ccc( dragPoint.pname, dragPoint );
                //}
                if( haz( dragPoint, 'hideD8Dpoint' ) || haz( dragPoint, 'lockD8D' )  ) return;
                var tdX = Math.abs( testMediaX - dragPoint.medpos[0] );
                var tdY = Math.abs( testMediaY - dragPoint.medpos[1] );
                var td  = Math.max( tdX, tdY );

                var distLim = haz( dragPoint, 'DRAGGEE_HALF_SIZE' ) || DRAGGEE_HALF_SIZE;
                if( td <= distLim ) {
                    if( !closestDragWrap || closestTd > td ||
                        (dragPoint.dragPriority || 0 ) > closestDragPriority ) {
                        closestDragWrap = dragWrap;
                        closestTd = td;
                        closestDragPriority = dragPoint.dragPriority || 0;

                        //vital-for-mobile
                        //ns.d('closest=' + dragPoint.pname +
                        //     ' fw' + dragWrap.createdFramework.frameworkId );
                   }
                }
            });
            ///used in full model-media area drag ...
            if( !closestDragWrap && unfoundDragger ) {
                closestDragWrap = unfoundDragger;
            }
            return closestDragWrap;
        }
        //====================
        // \\// finds draggee
        //====================








        //===============================
        // //\\ drag-time-runners
        //===============================
        //todo check note in buffer: slider
        //was: function doProcess_rgX( arg )
        function doProcess( arg )
        {
            var pWrap = arg.pointWrap; 
            switch( arg.down_move_up ) {
                case 'down':
                    ns.hafb( pWrap, 'processDownEvent' )( arg );
                    break;
                case 'up' :
                    ns.hafb( pWrap, 'processUpEvent' )(arg);
                    break;
                case 'move':
                    //move in model units
                    var mscale = 1; //out2inn() * inn2mod_scale;
                    var scaledMove = [
                        arg.surfMove[0] * mscale,
                        arg.surfMove[1] * mscale,
                    ];
                    //this sub. basically creates newPos from move
                    pWrap.move_2_updates(
                        scaledMove, //is in model units except for media-mover(-as-a-whole)
                    );
                    break;
            }
        }
        //==========================================
        // \\// attemt to unify dragger for point
        //==========================================

        function move_2_updates( dragMove, mouseOnSurf )
        {
            var newPos = [
                this.achieved.achieved[0] + dragMove[0],
                this.achieved.achieved[1] - dragMove[1],
            ];
            var accepted = this.acceptPos( newPos, dragMove );
            if( accepted ) {
                ns.paste( this.pos, newPos );
            }
        }

        ///must be in contex of pointWrap
        function processDownEvent( arg )
        {
            this.achieved.achieved = ns.paste( [], this.pos );
            //haff( this, 'processOwnDownEvent' );
        }

        function processUpEvent( arg )
        {
            //haff( this, 'processOwnUpEvent' );
        }
        //===============================
        // \\// drag-time-runners
        //===============================





        //===============================
        // //\\ inn2outparent and inverse
        //===============================
        ///wrong?: converts pos-in-media-scope to pos-in-dom-scope-related-to-media-dom-offset
        ///right?                              ....                        to-media-parent-dom-offset
        function inn2outparent()
        {
            var off     = mediaOffset;
            var medpos  = this.medpos;
            var i2o     = 1/out2inn();
            return [
                medpos[0] * i2o + off[0],

                //this is not required because of media root already margined, so
                //has been shifted as mediaLeftMargin
                // + sDomN.mediaLeftMargin,

                medpos[1] * i2o + off[1]
            ];
        };

        ///converts dom-pos to media pos
        ///for lemma1, drag_surface = sDomN.medRoot
        function outparent2inn( outparent )
        {
            var moffset = mediaOffset;
            var c2m     = out2inn();
            return [
                c2m * ( outparent[0] - moffset[0]
                        //- sDomN.mediaLeftMargin //media-root is already shifted ...
                      ),
                c2m * ( outparent[1] - moffset[1] )
            ];
        }
        function out2inn()
        {
            return innerMediaWidth / mediaWidth;
        }
        //===============================
        // \\// inn2outparent and inverse
        //===============================

    }

}) ();

