// this design implements app-model coord. system, not browser's css coord. system,

( function() {
    var {
        ns,
        mat,
        nspaste,
    } = window.b$l.nstree();
    mat.rotateDiv = rotateDiv; //todo move not to mat library
    return;



    function rotateDiv({
        scene,
        sprite,
        //[
        //    { axisIx, angle },
        //    { axisIx, angle },
        //    ...
        rotationSequence,
    }){
        var divDomEl    = sprite.dom;
        var finalMatrix = sprite.currentPosition;
        rotationSequence.forEach( (rotItem, rix) => {
            var mx = mat.rotates_aroundAxisN({
                n       : rotItem.axisIx,
                angle   : rotItem.angle,
            });
            if( !finalMatrix ) {
                finalMatrix = mx;
            } else {
                finalMatrix = mat.MxM( mx, finalMatrix, );
            }
        });
        sprite.currentPosition = nspaste( [], finalMatrix );

        //printMatirx( sprite.currentPosition )
        finalMatrix = mat.MxM( sprite.finalTransf, finalMatrix, );

        var pegIx = sprite.pegIx;
        var peg   = scene.pegs[ pegIx ];
        var inPos = peg.initialPos;

        finalMatrix[0][3] += inPos[0];
        finalMatrix[1][3] += inPos[1];
        finalMatrix[2][3] += inPos[2];;
        var css = mat.modelMatrix2css( finalMatrix );
        divDomEl.style.transform = css;
        divDomEl.style[ 'transform-origin' ] = '50% 50%';
    }

    function printMatirx( mx )
    {
        mx.forEach( row => {
            row.forEach( (cell,cix) => {
                row[cix] = parseFloat( row[cix].toFixed( 8 ) );  
            });
        });
        ccc( mx );
    }


}) ();


