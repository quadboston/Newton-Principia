( function() {
    var {
        nspaste, capture,
        ssF,
        stdMod, amode,
    } = window.b$l.apptree({
        ssFExportList :
        {
            amode2rgstate,
        },
    });
    setCapture();
    return;






    function setCapture()
    {
        nspaste( capture,
        {
        });
    }


    ///runs inside "subessay launch" which in turn runs after
    ///"init model parameters"
    function amode2rgstate( captured )
    {
        ssF.media_upcreate_generic();
        return captured;
    }

}) ();

