// //\\// if css order is important, set it here
(function() {
    var {
        ssCssOrder,
    } = window.b$l.apptree({
        setModule,
    });
    return;





    function setModule()
    {
        ssCssOrder.list =
        [
            'inner-page',
            'slider',
            'model',
        ];
    }


    

})();


